Hello there!
It is I, the goose!
If you want to get the flag, all you have to do is solve each riddle in ascending order.
There are images that are necesary in guiding you in the right direction, so remember to use them;

riddle1 = riddle1drawing1
riddle2 = riddle1drawing2
riddle3 = riddle1drawing3

Good luck!

~ goose